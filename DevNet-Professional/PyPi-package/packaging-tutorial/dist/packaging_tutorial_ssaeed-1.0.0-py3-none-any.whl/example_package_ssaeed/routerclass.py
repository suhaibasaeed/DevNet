class Router:
    def __init__(self, hostname, ipadd):
        self.hostname = hostname
        self.ipadd = ipadd
